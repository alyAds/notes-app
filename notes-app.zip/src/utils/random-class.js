const randomClass = [
  "note-1",
  "note-2",
  "note-3",
  "note-4",
  "note-5",
  "note-6",
  "note-7",
  "note-8",
];

export { randomClass };
