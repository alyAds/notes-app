const getData = () => {
  return [
    {
      id: 1,
      title: "Biaya Hidup",
      body: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda tempora sequi labore mollitia repellendus corporis aspernatur blanditiis earum voluptatum, consectetur veniam maiores saepe quidem consequuntur, deserunt amet nostrum excepturi voluptate enim repudiandae fugit quisquam sit! Non fuga quibusdam inventore architecto est saepe ducimus mollitia veritatis provident rerum? Vel, porro illum.",
      archived: false,
      style: "note-1",
      foundClass: '',
      createdAt: '2022-04-14 04:27:34',
    },
    {
      id: 2,
      title: "Renungan hati",
      body: "Assumenda tempora sequi labore mollitia repellendus corporis aspernatur blanditiis earum voluptatum, consectetur veniam maiores saepe quidem consequuntur, deserunt amet nostrum excepturi voluptate enim repudiandae fugit quisquam sit! Non fuga quibusdam inventore architecto est saepe ducimus mollitia veritatis provident rerum? Vel, porro illum. Lorem ipsum dolor, sit amet consectetur adipisicing elit.",
      archived: true,
      style: "note-2",
      foundClass: '',
      createdAt: '2022-04-14 04:27:34',
    },
    {
      id: 3,
      title: "Wajib lakukan hal ini diumur 20-an",
      body: "Vel, porro illum. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda tempora sequi labore mollitia repellendus corporis aspernatur blanditiis earum voluptatum, consectetur veniam maiores saepe quidem consequuntur, deserunt amet nostrum excepturi voluptate enim repudiandae fugit quisquam sit! Non fuga quibusdam inventore architecto est saepe ducimus mollitia veritatis provident rerum?",
      archived: true,
      style: "note-3",
      foundClass: '',
      createdAt: '2022-04-14 04:27:34',
    },
    {
      id: 4,
      title: "Makan ini bermanfaat",
      body: "Vel, porro illum. Assumenda tempora sequi labore mollitia repellendus corporis aspernatur blanditiis earum voluptatum, consectetur veniam maiores saepe quidem consequuntur, deserunt amet nostrum excepturi voluptate enim repudiandae fugit quisquam sit! Non fuga quibusdam inventore architecto est saepe ducimus mollitia veritatis provident rerum? Lorem ipsum dolor, sit amet consectetur adipisicing elit.",
      archived: false,
      style: "note-2",
      foundClass: '',
      createdAt: '2022-04-14 04:27:34',
    },
  ];
};

export { getData };
